import os
from qgis.PyQt.QtCore import Qt, QVariant, QSettings
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QComboBox, QPushButton, QMessageBox
)
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProject,
    QgsWkbTypes
)

from . import core_label_function

SETTINGS_GROUP = "/ContourLabelLadders/"


class ContourLabelLaddersDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Contour Label Ladders")
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)

        self.contour_combo = QComboBox()
        self.guide_combo = QComboBox()
        self.elev_combo = QComboBox()

        layout = QVBoxLayout()

        # Contour layer
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Contour layer:"))
        row1.addWidget(self.contour_combo)
        layout.addLayout(row1)

        # Guide layer
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Guide layer:"))
        row2.addWidget(self.guide_combo)
        layout.addLayout(row2)

        # Field
        row3 = QHBoxLayout()
        row3.addWidget(QLabel("Elevation field:"))
        row3.addWidget(self.elev_combo)
        layout.addLayout(row3)

        # Buttons
        btn_row = QHBoxLayout()
        self.run_btn = QPushButton("Generate labels")
        self.cancel_btn = QPushButton("Close")
        btn_row.addWidget(self.run_btn)
        btn_row.addWidget(self.cancel_btn)
        layout.addLayout(btn_row)

        self.setLayout(layout)

        # Populate lists and restore saved state
        self.populate_layer_combos()
        self.restore_saved_selections()
        self.update_elev_fields()

        # Signals
        self.contour_combo.currentIndexChanged.connect(self.update_elev_fields)
        self.run_btn.clicked.connect(self._run_button_clicked)
        self.cancel_btn.clicked.connect(self.reject)

    def populate_layer_combos(self):
        """Fill dropdowns with line layers from project."""
        self.contour_combo.clear()
        self.guide_combo.clear()

        project = QgsProject.instance()

        for lyr in project.mapLayers().values():
            if getattr(lyr, "geometryType", None) and lyr.geometryType() == QgsWkbTypes.LineGeometry:
                self.contour_combo.addItem(lyr.name())
                self.guide_combo.addItem(lyr.name())

        # Smart guide preselect if exactly one feature is selected
        for lyr in project.mapLayers().values():
            if getattr(lyr, "selectedFeatureCount", None) == 1:
                if lyr.geometryType() == QgsWkbTypes.LineGeometry:
                    idx = self.guide_combo.findText(lyr.name())
                    if idx >= 0:
                        self.guide_combo.setCurrentIndex(idx)
                        break

    def restore_saved_selections(self):
        """Restore combo selections from QGIS settings."""
        s = QSettings()

        last_contour = s.value(SETTINGS_GROUP + "lastContourLayer", "", type=str)
        last_guide = s.value(SETTINGS_GROUP + "lastGuideLayer", "", type=str)
        last_field = s.value(SETTINGS_GROUP + "lastElevField", "", type=str)

        idx = self.contour_combo.findText(last_contour)
        if idx >= 0:
            self.contour_combo.setCurrentIndex(idx)

        idx = self.guide_combo.findText(last_guide)
        if idx >= 0:
            self.guide_combo.setCurrentIndex(idx)

        self._last_field_name = last_field

    def update_elev_fields(self):
        """Fill elevation field dropdown with numeric fields."""
        self.elev_combo.clear()

        contour_name = self.contour_combo.currentText()
        if not contour_name:
            return

        layer = QgsProject.instance().mapLayersByName(contour_name)[0]

        for f in layer.fields():
            if f.type() in (QVariant.Int, QVariant.Double, QVariant.LongLong):
                self.elev_combo.addItem(f.name())

        # Restore selected if available
        if hasattr(self, "_last_field_name"):
            idx = self.elev_combo.findText(self._last_field_name)
            if idx >= 0:
                self.elev_combo.setCurrentIndex(idx)
                
    def refresh_layers(self):
        """Reload available line layers and restore selections if possible."""
        old_contour = self.contour_combo.currentText()
        old_guide = self.guide_combo.currentText()

        self.populate_layer_combos()
        self.update_elev_fields()

        # Try restore previous dropdown choices
        idx = self.contour_combo.findText(old_contour)
        if idx >= 0:
            self.contour_combo.setCurrentIndex(idx)

        idx = self.guide_combo.findText(old_guide)
        if idx >= 0:
            self.guide_combo.setCurrentIndex(idx)


    def _run_button_clicked(self):
        """Validate then call core algorithm."""
        contour_name = self.contour_combo.currentText()
        guide_name = self.guide_combo.currentText()
        elev_field = self.elev_combo.currentText()

        if not contour_name or not guide_name or not elev_field:
            QMessageBox.warning(self, "Contour Label Ladders",
                                "Choose contour layer, guide layer, and elevation field.")
            return

        project = QgsProject.instance()

        contour_layer = project.mapLayersByName(contour_name)[0]
        guide_layer = project.mapLayersByName(guide_name)[0]

        if guide_layer.selectedFeatureCount() != 1:
            QMessageBox.warning(self, "Contour Label Ladders",
                                "Select exactly one guide line feature.")
            return

        # Save settings
        s = QSettings()
        s.setValue(SETTINGS_GROUP + "lastContourLayer", contour_name)
        s.setValue(SETTINGS_GROUP + "lastGuideLayer", guide_name)
        s.setValue(SETTINGS_GROUP + "lastElevField", elev_field)

        core_label_function.ELEVATION_FIELD = elev_field
        core_label_function.create_labels(contour_name, guide_name)

        QMessageBox.information(self, "Contour Label Ladders",
                                "Labels generated. Select next guide and click again.")


class ContourLabelLaddersPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self._dlg = None
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(QIcon(icon_path), "Contour Label Ladders", self.iface.mainWindow())
        self.action.triggered.connect(self.open_dialog)
        # Reload layer lists when plugin icon clicked again
        self.action.triggered.connect(self.force_refresh)


        self.iface.addPluginToMenu("Contour Label Ladders", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("Contour Label Ladders", self.action)
        self.iface.removeToolBarIcon(self.action)

    def open_dialog(self):
        if self._dlg is None:
            self._dlg = ContourLabelLaddersDialog(self.iface.mainWindow())

        self._dlg.show()
        self._dlg.raise_()
        self._dlg.activateWindow()
    def force_refresh(self):
        if self._dlg is not None:
            self._dlg.refresh_layers()

