def classFactory(iface):
    from .contour_label_ladders import ContourLabelLaddersPlugin
    return ContourLabelLaddersPlugin(iface)